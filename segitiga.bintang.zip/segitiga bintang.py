for i in range(6):
    print(' '*(6-i-1)+'*'*(2*i+1))
print()