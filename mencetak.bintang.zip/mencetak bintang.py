for i in range(8):
    for j in range(i):
        print(" ",end="")
    for k in range(8-i):
        print("*",end="")
    print()